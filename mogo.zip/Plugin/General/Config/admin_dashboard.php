<?php

$config = array(
	'example.welcome' => array(
		'title' => __d('croogo', 'Welcome'),
		'element' => 'Example.dashboard/welcome',
		'weight' => 1,
		'column' => CroogoDashboard::FULL,
	),
);