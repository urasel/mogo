<?php

App::uses('AppController', 'Controller');

class InformationAppController extends AppController {

}
