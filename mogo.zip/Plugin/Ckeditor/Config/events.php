<?php

$config = array(
	'EventHandlers' => array(
		'Ckeditor.CkeditorEventHandler' => array(
			'priority' => 20,
		),
	),
);
