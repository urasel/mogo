<?php

App::uses('CroogoAppShell', 'Croogo.Console');

/**
 * Base Application Shell
 *
 * @package  Croogo
 * @link     http://www.croogo.org
 */
class AppShell extends CroogoAppShell {

}