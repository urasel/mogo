<?php

App::uses('AppController', 'Controller');

class GeneralAppController extends AppController {

}
