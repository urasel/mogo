<?php

App::uses('AppModel', 'Model');

class GeneralAppModel extends AppModel {

}
