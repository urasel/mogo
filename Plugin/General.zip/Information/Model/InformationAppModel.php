<?php

App::uses('AppModel', 'Model');

class InformationAppModel extends AppModel {

}
