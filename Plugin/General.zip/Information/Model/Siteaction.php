<?php
App::uses('InformationAppModel', 'Information.Model');
/**
 * Siteaction Model
 *
 */
class Siteaction extends InformationAppModel {

}
