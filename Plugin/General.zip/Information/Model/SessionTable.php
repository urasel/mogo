<?php
App::uses('InformationAppModel', 'Information.Model');
/**
 * SessionTable Model
 *
 */
class SessionTable extends InformationAppModel {

}
