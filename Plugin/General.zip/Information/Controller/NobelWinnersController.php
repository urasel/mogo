<?php
App::uses('InformationAppController', 'Information.Controller');
/**
 * NobelWinners Controller
 *
 */
class NobelWinnersController extends InformationAppController {

/**
 * Scaffold
 *
 * @var mixed
 */
	public $scaffold;

}
