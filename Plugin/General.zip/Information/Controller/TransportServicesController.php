<?php
App::uses('InformationAppController', 'Information.Controller');
/**
 * TransportServices Controller
 *
 * @property TransportService $TransportService
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class TransportServicesController extends InformationAppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->TransportService->recursive = 0;
		$this->set('transportServices', $this->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->TransportService->exists($id)) {
			throw new NotFoundException(__d('croogo', 'Invalid %s', __d('information', 'transport service')));
		}
		$options = array('conditions' => array('TransportService.' . $this->TransportService->primaryKey => $id));
		$this->set('transportService', $this->TransportService->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->TransportService->create();
			if ($this->TransportService->saveAssociated($this->request->data)) {
				$this->Session->setFlash(__d('croogo', '%s has been saved', __d('information', 'transport service')), 'default', array('class' => 'success'));
				$redirectTo = array('action' => 'index');
				if (isset($this->request->data['apply'])) {
					$redirectTo = array('action' => 'edit', $this->TransportService->id);
				}
				if (isset($this->request->data['save_and_new'])) {
					$redirectTo = array('action' => 'add');
				}
				return $this->redirect($redirectTo);
			} else {
				$this->Session->setFlash(__d('croogo', '%s could not be saved. Please, try again.', __d('information', 'transport service')), 'default', array('class' => 'error'));
			}
		}
		$points = $this->TransportService->Point->find('list');
		$placeTypes = $this->TransportService->PlaceType->find('list');
		$transportTypes = $this->TransportService->TransportType->find('list');
		$transportServiceProviders = $this->TransportService->TransportServiceProvider->find('list');
		$this->set(compact('points', 'placeTypes', 'transportTypes', 'transportServiceProviders'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->TransportService->exists($id)) {
			throw new NotFoundException(__d('croogo', 'Invalid %s', __d('information', 'transport service')));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			if ($this->TransportService->saveAssociated($this->request->data)) {
				$this->Session->setFlash(__d('croogo', '%s has been saved', __d('information', 'transport service')), 'default', array('class' => 'success'));
				$redirectTo = array('action' => 'index');
				if (isset($this->request->data['apply'])) {
					$redirectTo = array('action' => 'edit', $id);
				}
				if (isset($this->request->data['save_and_new'])) {
					$redirectTo = array('action' => 'add');
				}
				return $this->redirect($redirectTo);
			} else {
				$this->Session->setFlash(__d('croogo', '%s could not be saved. Please, try again.', __d('information', 'transport service')), 'default', array('class' => 'error'));
			}
		} else {
			$options = array('conditions' => array('TransportService.' . $this->TransportService->primaryKey => $id));
			$this->request->data = $this->TransportService->find('first', $options);
		}
		$points = $this->TransportService->Point->find('list');
		$placeTypes = $this->TransportService->PlaceType->find('list');
		$transportTypes = $this->TransportService->TransportType->find('list');
		$transportServiceProviders = $this->TransportService->TransportServiceProvider->find('list');
		$this->set(compact('points', 'placeTypes', 'transportTypes', 'transportServiceProviders'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->TransportService->id = $id;
		if (!$this->TransportService->exists()) {
			throw new NotFoundException(__d('croogo', 'Invalid %s', __d('information', 'transport service')));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->TransportService->delete()) {
			$this->Session->setFlash(__d('croogo', '%s deleted', __d('information', 'Transport service')), 'default', array('class' => 'success'));
			return $this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__d('croogo', '%s was not deleted', __d('information', 'Transport service')), 'default', array('class' => 'error'));
		return $this->redirect(array('action' => 'index'));
	}
/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->TransportService->recursive = 0;
		$this->set('transportServices', $this->paginate());
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		if (!$this->TransportService->exists($id)) {
			throw new NotFoundException(__d('croogo', 'Invalid %s', __d('information', 'transport service')));
		}
		$options = array('conditions' => array('TransportService.' . $this->TransportService->primaryKey => $id));
		$this->set('transportService', $this->TransportService->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->TransportService->create();
			if ($this->TransportService->saveAssociated($this->request->data)) {
				$this->Session->setFlash(__d('croogo', '%s has been saved', __d('information', 'transport service')), 'default', array('class' => 'success'));
				$redirectTo = array('action' => 'index');
				if (isset($this->request->data['apply'])) {
					$redirectTo = array('action' => 'edit', $this->TransportService->id);
				}
				if (isset($this->request->data['save_and_new'])) {
					$redirectTo = array('action' => 'add');
				}
				return $this->redirect($redirectTo);
			} else {
				$this->Session->setFlash(__d('croogo', '%s could not be saved. Please, try again.', __d('information', 'transport service')), 'default', array('class' => 'error'));
			}
		}
		//$points = $this->TransportService->Point->find('list');
		$placeTypes = $this->TransportService->PlaceType->find('list');
		$transportTypes = $this->TransportService->TransportType->find('list');
		$transportServiceProviders = $this->TransportService->TransportServiceProvider->find('list');
		$this->set(compact( 'placeTypes', 'transportTypes', 'transportServiceProviders'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		if (!$this->TransportService->exists($id)) {
			throw new NotFoundException(__d('croogo', 'Invalid %s', __d('information', 'transport service')));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			if ($this->TransportService->saveAssociated($this->request->data)) {
				$this->Session->setFlash(__d('croogo', '%s has been saved', __d('information', 'transport service')), 'default', array('class' => 'success'));
				$redirectTo = array('action' => 'index');
				if (isset($this->request->data['apply'])) {
					$redirectTo = array('action' => 'edit', $id);
				}
				if (isset($this->request->data['save_and_new'])) {
					$redirectTo = array('action' => 'add');
				}
				return $this->redirect($redirectTo);
			} else {
				$this->Session->setFlash(__d('croogo', '%s could not be saved. Please, try again.', __d('information', 'transport service')), 'default', array('class' => 'error'));
			}
		} else {
			$options = array('conditions' => array('TransportService.' . $this->TransportService->primaryKey => $id));
			$this->request->data = $this->TransportService->find('first', $options);
		}
		//$points = $this->TransportService->Point->find('list');
		$placeTypes = $this->TransportService->PlaceType->find('list');
		$transportTypes = $this->TransportService->TransportType->find('list');
		$transportServiceProviders = $this->TransportService->TransportServiceProvider->find('list');
		$this->set(compact('placeTypes', 'transportTypes', 'transportServiceProviders'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		$this->TransportService->id = $id;
		if (!$this->TransportService->exists()) {
			throw new NotFoundException(__d('croogo', 'Invalid %s', __d('information', 'transport service')));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->TransportService->delete()) {
			$this->Session->setFlash(__d('croogo', '%s deleted', __d('information', 'Transport service')), 'default', array('class' => 'success'));
			return $this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__d('croogo', '%s was not deleted', __d('information', 'Transport service')), 'default', array('class' => 'error'));
		return $this->redirect(array('action' => 'index'));
	}
}
