<?php

CroogoRouter::connect('/', array(
	'plugin' => 'information', 'controller' => 'topics', 'action' => 'home',
));


