<?php
App::uses('NobelWinnersController', 'Information.Controller');

/**
 * NobelWinnersController Test Case
 *
 */
class NobelWinnersControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'plugin.information.nobel_winner'
	);

}
