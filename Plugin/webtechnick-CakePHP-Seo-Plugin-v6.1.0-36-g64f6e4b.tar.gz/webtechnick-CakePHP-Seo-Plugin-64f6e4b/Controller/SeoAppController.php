<?php
App::uses('SeoUtil', 'Seo.Lib');
App::uses('AppController','Controller');
class SeoAppController extends AppController {
}